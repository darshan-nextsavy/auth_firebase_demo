package com.nst.auth_firebase_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
